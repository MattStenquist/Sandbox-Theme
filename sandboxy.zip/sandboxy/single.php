<?php 
get_header();?>

<!-- BUILD OUT THE SINGLE PAGE HERE FOR INNER-POST VIEWS -->